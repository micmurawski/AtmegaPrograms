#ifndef lcd_lib
#define