#ifndef lcd_lib
#define lcd_lib

void lcd_write_byte(uint8_t data)
void lcd_write_cmd(uint8_t cmd)
void lcd_write_data(uint8_t data)


#endif